from brain_games.games.gcd import play


def main():
    play()


if __name__ == "__main__":
    main()