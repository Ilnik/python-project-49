import random


def get_random_number_from_range():
    return random.randint(1, 10)
