### Hexlet tests and linter status:
[![Actions Status](https://github.com/Ilnik/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Ilnik/python-project-49/actions)
<a href="https://codeclimate.com/github/Ilnik/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/1c77845b2c6a691b5685/maintainability" /></a>
<a href="https://asciinema.org/a/645040" target="_blank"><img src="https://asciinema.org/a/645040.svg" /></a>
<a href="https://asciinema.org/a/645172" target="_blank"><img src="https://asciinema.org/a/645172.svg" /></a>
<a href="https://asciinema.org/a/645185" target="_blank"><img src="https://asciinema.org/a/645185.svg" /></a>