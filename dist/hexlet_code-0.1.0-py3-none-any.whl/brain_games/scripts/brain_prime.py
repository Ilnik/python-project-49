from brain_games.games.prime import play


def main():
    play()


if __name__ == "__main__":
    main()
