from brain_games.games.calc import play


def main():
    play()


if __name__ == "__main__":
    main()